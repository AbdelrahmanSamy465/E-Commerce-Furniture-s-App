# E-commerce-furnitures-App
E-commerce App for furnitures, open source mobile app for Shopping . Built with java. and firebase and mvc-architecture 


![5f21bd18-dec6-419d-b814-cd19a04f1f11](https://user-images.githubusercontent.com/81165867/121568823-66f49000-ca20-11eb-935c-8d890d311a6b.jpg)
![6de6fed8-a706-40c8-9001-701abf0c1cfb](https://user-images.githubusercontent.com/81165867/121568986-9a371f00-ca20-11eb-92a2-7b89f9d7f9d9.jpg)
![194f0deb-75de-477f-9e1b-b6557b19bd89](https://user-images.githubusercontent.com/81165867/121569002-9dcaa600-ca20-11eb-8eb2-e71d670a5e78.jpg)
![6955a26f-1a2e-4de7-96eb-029f97ce84a7](https://user-images.githubusercontent.com/81165867/121569020-a28f5a00-ca20-11eb-8f5a-96bad710f303.jpg)
![d1589d08-eb60-47af-b285-2f4adaf8eb02](https://user-images.githubusercontent.com/81165867/121569028-a4f1b400-ca20-11eb-9d8b-babac5581ba4.jpg)
![9e443b99-0108-4c02-955b-7db0641108fe](https://user-images.githubusercontent.com/81165867/121569041-a8853b00-ca20-11eb-8bc2-d730622135bb.jpg)
![81198b4d-48ab-44e9-86c2-bd5b0a2fc281](https://user-images.githubusercontent.com/81165867/121569050-aa4efe80-ca20-11eb-8686-bc45d3de01b5.jpg)

