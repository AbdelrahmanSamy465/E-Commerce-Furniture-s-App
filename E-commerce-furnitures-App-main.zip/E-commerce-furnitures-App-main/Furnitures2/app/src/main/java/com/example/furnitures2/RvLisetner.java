package com.example.furnitures2;

public interface RvLisetner {
    public void OnitemClicked(int position);
}
