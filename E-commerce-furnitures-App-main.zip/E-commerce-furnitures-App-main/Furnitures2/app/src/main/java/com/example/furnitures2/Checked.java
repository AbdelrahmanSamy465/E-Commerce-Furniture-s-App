package com.example.furnitures2;

public class Checked {
    String image;

    public Checked(String image) {
        this.image = image;
    }

    public Checked() {
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
